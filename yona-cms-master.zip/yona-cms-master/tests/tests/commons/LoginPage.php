<?php
 /**
 * @copyright Copyright (c) 2011 - 2014 Oleksandr Torosh (http://wezoom.net)
 * @author Oleksandr Torosh <web@wezoom.net>
 */

class LoginPage
{
    public static $usernameField = '#login';
    public static $passwordField = '#password';
    public static $loginButton = '#submit';

} 