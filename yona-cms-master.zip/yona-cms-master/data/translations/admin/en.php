<?php

return [
    'Warning. Found admin user with name yona' => 'Found the administrative user <b>yona</b>, to comply with security measures, it is necessary to Delete and create a new personal account',
    'Filemanager recomendation' => 'To properly open files on the site, it is recommended replace their non-latin or Cyrillic names of files to latin (English)',
];